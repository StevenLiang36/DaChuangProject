from UMS.models import UserInfo, MyTeam
from django.shortcuts import render, HttpResponse, redirect

def developerList(request):
    data_list = MyTeam.objects.all()
    return render(request, 'developerList.html', {'data_list': data_list})